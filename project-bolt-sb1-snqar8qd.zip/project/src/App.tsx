import React, { useState } from 'react';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import BookingsManager from './components/BookingsManager';
import RoomsManager from './components/RoomsManager';
import GuestsManager from './components/GuestsManager';
import PaymentsManager from './components/PaymentsManager';
import Settings from './components/Settings';

function App() {
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <Dashboard />;
      case 'bookings':
        return <BookingsManager />;
      case 'rooms':
        return <RoomsManager />;
      case 'guests':
        return <GuestsManager />;
      case 'payments':
        return <PaymentsManager />;
      case 'settings':
        return <Settings />;
      default:
        return <Dashboard />;
    }
  };

  return (
    <Layout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </Layout>
  );
}

export default App;