import React from 'react';
import { Bed, Users, Calendar, DollarSign, TrendingUp, Clock } from 'lucide-react';
import { rooms, bookings, guests, payments } from '../data/mockData';
import { HotelStats } from '../types';

const Dashboard: React.FC = () => {
  // Calculate stats
  const stats: HotelStats = {
    totalRooms: rooms.length,
    occupiedRooms: rooms.filter(room => !room.isAvailable).length,
    availableRooms: rooms.filter(room => room.isAvailable).length,
    todayCheckIns: bookings.filter(booking => 
      booking.checkIn === new Date().toISOString().split('T')[0]
    ).length,
    todayCheckOuts: bookings.filter(booking => 
      booking.checkOut === new Date().toISOString().split('T')[0]
    ).length,
    totalRevenue: payments
      .filter(p => p.status === 'completed')
      .reduce((sum, payment) => sum + payment.amount, 0)
  };

  const occupancyRate = Math.round((stats.occupiedRooms / stats.totalRooms) * 100);

  const statCards = [
    {
      title: 'Total Rooms',
      value: stats.totalRooms,
      icon: Bed,
      color: 'bg-blue-500',
      change: '+2%'
    },
    {
      title: 'Occupied Rooms',
      value: stats.occupiedRooms,
      icon: Users,
      color: 'bg-green-500',
      change: '+5%'
    },
    {
      title: 'Today Check-ins',
      value: stats.todayCheckIns,
      icon: Calendar,
      color: 'bg-yellow-500',
      change: '0%'
    },
    {
      title: 'Total Revenue',
      value: `$${stats.totalRevenue.toLocaleString()}`,
      icon: DollarSign,
      color: 'bg-purple-500',
      change: '+12%'
    }
  ];

  const recentBookings = bookings.slice(0, 5);

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Dashboard</h1>
        <p className="text-gray-600">Welcome back! Here's what's happening at your hotel today.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statCards.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow duration-200">
              <div className="flex items-center justify-between mb-4">
                <div className={`p-3 rounded-lg ${stat.color}`}>
                  <Icon className="h-6 w-6 text-white" />
                </div>
                <div className="flex items-center text-sm text-green-600">
                  <TrendingUp className="h-4 w-4 mr-1" />
                  {stat.change}
                </div>
              </div>
              <div>
                <p className="text-sm text-gray-500 mb-1">{stat.title}</p>
                <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Occupancy Chart */}
        <div className="lg:col-span-2 bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Room Occupancy</h2>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600">Occupancy Rate</span>
              <span className="text-sm font-medium text-gray-900">{occupancyRate}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-3">
              <div 
                className="bg-gradient-to-r from-blue-500 to-blue-600 h-3 rounded-full transition-all duration-500"
                style={{ width: `${occupancyRate}%` }}
              ></div>
            </div>
            <div className="grid grid-cols-3 gap-4 mt-6">
              <div className="text-center">
                <p className="text-2xl font-bold text-blue-600">{stats.availableRooms}</p>
                <p className="text-sm text-gray-500">Available</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{stats.occupiedRooms}</p>
                <p className="text-sm text-gray-500">Occupied</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold text-gray-600">{stats.totalRooms}</p>
                <p className="text-sm text-gray-500">Total</p>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Bookings */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <h2 className="text-xl font-semibold text-gray-900 mb-6">Recent Bookings</h2>
          <div className="space-y-4">
            {recentBookings.map((booking) => {
              const guest = guests.find(g => g.id === booking.guestId);
              const room = rooms.find(r => r.id === booking.roomId);
              
              return (
                <div key={booking.id} className="flex items-center justify-between p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors duration-200">
                  <div>
                    <p className="font-medium text-gray-900">{guest?.firstName} {guest?.lastName}</p>
                    <div className="flex items-center text-sm text-gray-500">
                      <Clock className="h-3 w-3 mr-1" />
                      Room {room?.number}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-medium text-gray-900">${booking.totalAmount}</p>
                    <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
                      booking.status === 'confirmed' ? 'bg-green-100 text-green-800' :
                      booking.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {booking.status}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;