import React, { useState } from 'react';
import { Bed, Users, Wifi, Tv, Wind, Coffee, Eye, Edit } from 'lucide-react';
import { Room } from '../types';
import { rooms as initialRooms } from '../data/mockData';

const RoomsManager: React.FC = () => {
  const [rooms, setRooms] = useState<Room[]>(initialRooms);
  const [filter, setFilter] = useState('all');

  const filteredRooms = rooms.filter(room => {
    if (filter === 'all') return true;
    if (filter === 'available') return room.isAvailable;
    if (filter === 'occupied') return !room.isAvailable;
    return room.type === filter;
  });

  const getAmenityIcon = (amenity: string) => {
    switch (amenity.toLowerCase()) {
      case 'wifi': return <Wifi className="h-4 w-4" />;
      case 'tv': return <Tv className="h-4 w-4" />;
      case 'air conditioning': return <Wind className="h-4 w-4" />;
      case 'mini bar': return <Coffee className="h-4 w-4" />;
      default: return <span className="w-4 h-4 bg-gray-300 rounded-full" />;
    }
  };

  const getRoomTypeColor = (type: string) => {
    switch (type) {
      case 'single': return 'bg-blue-100 text-blue-800';
      case 'double': return 'bg-green-100 text-green-800';
      case 'suite': return 'bg-purple-100 text-purple-800';
      case 'deluxe': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Rooms Management</h1>
        <p className="text-gray-600">Manage hotel rooms, availability, and room details.</p>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 mb-6">
        <div className="flex flex-wrap gap-3">
          <button
            onClick={() => setFilter('all')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
              filter === 'all' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            All Rooms ({rooms.length})
          </button>
          <button
            onClick={() => setFilter('available')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
              filter === 'available' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Available ({rooms.filter(r => r.isAvailable).length})
          </button>
          <button
            onClick={() => setFilter('occupied')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
              filter === 'occupied' ? 'bg-red-100 text-red-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Occupied ({rooms.filter(r => !r.isAvailable).length})
          </button>
          <button
            onClick={() => setFilter('single')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
              filter === 'single' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Single
          </button>
          <button
            onClick={() => setFilter('double')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
              filter === 'double' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Double
          </button>
          <button
            onClick={() => setFilter('suite')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
              filter === 'suite' ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Suite
          </button>
          <button
            onClick={() => setFilter('deluxe')}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
              filter === 'deluxe' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }`}
          >
            Deluxe
          </button>
        </div>
      </div>

      {/* Rooms Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRooms.map((room) => (
          <div key={room.id} className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow duration-200">
            <div className="relative">
              <img
                src={room.image}
                alt={`Room ${room.number}`}
                className="w-full h-48 object-cover"
              />
              <div className="absolute top-4 left-4">
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium capitalize ${getRoomTypeColor(room.type)}`}>
                  {room.type}
                </span>
              </div>
              <div className="absolute top-4 right-4">
                <span className={`inline-block px-3 py-1 rounded-full text-xs font-medium ${
                  room.isAvailable ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                }`}>
                  {room.isAvailable ? 'Available' : 'Occupied'}
                </span>
              </div>
            </div>
            
            <div className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-xl font-semibold text-gray-900">Room {room.number}</h3>
                <div className="text-right">
                  <p className="text-2xl font-bold text-blue-600">${room.price}</p>
                  <p className="text-sm text-gray-500">per night</p>
                </div>
              </div>
              
              <div className="flex items-center text-gray-600 mb-4">
                <Users className="h-4 w-4 mr-2" />
                <span className="text-sm">Up to {room.capacity} guests</span>
              </div>
              
              <div className="mb-6">
                <p className="text-sm text-gray-600 mb-2">Amenities:</p>
                <div className="flex flex-wrap gap-2">
                  {room.amenities.map((amenity, index) => (
                    <div key={index} className="flex items-center bg-gray-50 px-3 py-1 rounded-full">
                      {getAmenityIcon(amenity)}
                      <span className="text-xs text-gray-700 ml-1">{amenity}</span>
                    </div>
                  ))}
                </div>
              </div>
              
              <div className="flex space-x-2">
                <button className="flex-1 flex items-center justify-center px-3 py-2 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100 transition-colors duration-200">
                  <Eye className="h-4 w-4 mr-2" />
                  View
                </button>
                <button className="flex-1 flex items-center justify-center px-3 py-2 bg-gray-50 text-gray-600 rounded-lg hover:bg-gray-100 transition-colors duration-200">
                  <Edit className="h-4 w-4 mr-2" />
                  Edit
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredRooms.length === 0 && (
        <div className="text-center py-12">
          <Bed className="h-12 w-12 text-gray-300 mx-auto mb-4" />
          <p className="text-gray-500">No rooms found matching the selected filter.</p>
        </div>
      )}
    </div>
  );
};

export default RoomsManager;