import React, { useState } from 'react';
import { X, CreditCard, DollarSign, Calendar, Receipt } from 'lucide-react';
import { Payment, Booking } from '../types';
import { bookings, guests, rooms } from '../data/mockData';

interface PaymentFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (payment: Omit<Payment, 'id' | 'createdAt'>) => void;
  bookingId?: string;
}

const PaymentForm: React.FC<PaymentFormProps> = ({ isOpen, onClose, onSubmit, bookingId }) => {
  const [formData, setFormData] = useState({
    bookingId: bookingId || '',
    amount: 0,
    method: 'card' as const,
    transactionId: '',
    notes: ''
  });

  const selectedBooking = bookings.find(b => b.id === formData.bookingId);
  const guest = selectedBooking ? guests.find(g => g.id === selectedBooking.guestId) : null;
  const room = selectedBooking ? rooms.find(r => r.id === selectedBooking.roomId) : null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    onSubmit({
      bookingId: formData.bookingId,
      amount: formData.amount,
      method: formData.method,
      status: 'completed',
      transactionId: formData.transactionId || undefined,
      paidAt: new Date().toISOString(),
      notes: formData.notes
    });

    onClose();
    setFormData({
      bookingId: '',
      amount: 0,
      method: 'card',
      transactionId: '',
      notes: ''
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full">
        <div className="flex items-center justify-between p-6 border-b border-gray-200">
          <h2 className="text-xl font-semibold text-gray-900">Process Payment</h2>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors duration-200"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {/* Booking Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Booking</label>
            <select
              value={formData.bookingId}
              onChange={(e) => {
                const booking = bookings.find(b => b.id === e.target.value);
                setFormData({ 
                  ...formData, 
                  bookingId: e.target.value,
                  amount: booking?.totalAmount || 0
                });
              }}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            >
              <option value="">Select a booking</option>
              {bookings.map((booking) => {
                const bookingGuest = guests.find(g => g.id === booking.guestId);
                const bookingRoom = rooms.find(r => r.id === booking.roomId);
                return (
                  <option key={booking.id} value={booking.id}>
                    {bookingGuest?.firstName} {bookingGuest?.lastName} - Room {bookingRoom?.number} (${booking.totalAmount})
                  </option>
                );
              })}
            </select>
          </div>

          {/* Booking Details */}
          {selectedBooking && (
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-medium text-gray-900 mb-2">Booking Details</h3>
              <div className="space-y-1 text-sm text-gray-600">
                <p><span className="font-medium">Guest:</span> {guest?.firstName} {guest?.lastName}</p>
                <p><span className="font-medium">Room:</span> {room?.number} ({room?.type})</p>
                <p><span className="font-medium">Check-in:</span> {new Date(selectedBooking.checkIn).toLocaleDateString()}</p>
                <p><span className="font-medium">Check-out:</span> {new Date(selectedBooking.checkOut).toLocaleDateString()}</p>
                <p><span className="font-medium">Total Amount:</span> ${selectedBooking.totalAmount}</p>
              </div>
            </div>
          )}

          {/* Amount */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Amount</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="number"
                step="0.01"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: parseFloat(e.target.value) || 0 })}
                className="w-full pl-10 pr-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                required
                min="0"
              />
            </div>
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Payment Method</label>
            <select
              value={formData.method}
              onChange={(e) => setFormData({ ...formData, method: e.target.value as any })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              required
            >
              <option value="card">Credit/Debit Card</option>
              <option value="cash">Cash</option>
              <option value="bank_transfer">Bank Transfer</option>
              <option value="mobile_money">Mobile Money</option>
            </select>
          </div>

          {/* Transaction ID */}
          {formData.method !== 'cash' && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Transaction ID (Optional)</label>
              <input
                type="text"
                value={formData.transactionId}
                onChange={(e) => setFormData({ ...formData, transactionId: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Enter transaction reference"
              />
            </div>
          )}

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Notes</label>
            <textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              rows={3}
              placeholder="Payment notes or additional information..."
            />
          </div>

          {/* Actions */}
          <div className="flex space-x-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors duration-200"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors duration-200"
            >
              Process Payment
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default PaymentForm;