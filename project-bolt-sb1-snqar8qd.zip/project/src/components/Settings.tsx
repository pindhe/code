import React from 'react';
import { Settings as SettingsIcon, Bell, Lock, Palette, Globe, Database } from 'lucide-react';

const Settings: React.FC = () => {
  const settingsGroups = [
    {
      title: 'General',
      icon: SettingsIcon,
      settings: [
        { name: 'Hotel Name', value: 'HotelPro Management', type: 'text' },
        { name: 'Contact Email', value: 'admin@hotelpro.com', type: 'email' },
        { name: 'Phone Number', value: '+252-61-1234567', type: 'tel' },
        { name: 'Address', value: 'Mogadishu, Somalia', type: 'text' }
      ]
    },
    {
      title: 'Notifications',
      icon: Bell,
      settings: [
        { name: 'Email Notifications', value: true, type: 'toggle' },
        { name: 'SMS Notifications', value: false, type: 'toggle' },
        { name: 'Check-in Reminders', value: true, type: 'toggle' },
        { name: 'Payment Alerts', value: true, type: 'toggle' }
      ]
    },
    {
      title: 'Security',
      icon: Lock,
      settings: [
        { name: 'Two-Factor Authentication', value: false, type: 'toggle' },
        { name: 'Session Timeout (minutes)', value: '30', type: 'number' },
        { name: 'Password Policy', value: 'Strong', type: 'select' },
        { name: 'Login Attempts', value: '3', type: 'number' }
      ]
    },
    {
      title: 'Appearance',
      icon: Palette,
      settings: [
        { name: 'Theme', value: 'Light', type: 'select' },
        { name: 'Language', value: 'English', type: 'select' },
        { name: 'Date Format', value: 'MM/DD/YYYY', type: 'select' },
        { name: 'Currency', value: 'USD', type: 'select' }
      ]
    }
  ];

  return (
    <div className="p-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Settings</h1>
        <p className="text-gray-600">Manage your hotel management system preferences and configuration.</p>
      </div>

      <div className="space-y-6">
        {settingsGroups.map((group, index) => {
          const Icon = group.icon;
          return (
            <div key={index} className="bg-white rounded-xl shadow-sm border border-gray-200">
              <div className="p-6 border-b border-gray-200">
                <div className="flex items-center">
                  <div className="p-2 bg-blue-100 rounded-lg mr-3">
                    <Icon className="h-5 w-5 text-blue-600" />
                  </div>
                  <h2 className="text-lg font-semibold text-gray-900">{group.title}</h2>
                </div>
              </div>
              
              <div className="p-6">
                <div className="space-y-4">
                  {group.settings.map((setting, settingIndex) => (
                    <div key={settingIndex} className="flex items-center justify-between py-3">
                      <div>
                        <h3 className="text-sm font-medium text-gray-900">{setting.name}</h3>
                      </div>
                      
                      <div className="flex items-center">
                        {setting.type === 'toggle' ? (
                          <button
                            className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 ${
                              setting.value ? 'bg-blue-600' : 'bg-gray-200'
                            }`}
                          >
                            <span
                              className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform duration-200 ${
                                setting.value ? 'translate-x-6' : 'translate-x-1'
                              }`}
                            />
                          </button>
                        ) : setting.type === 'select' ? (
                          <select
                            defaultValue={setting.value as string}
                            className="border border-gray-300 rounded-lg px-3 py-1 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          >
                            <option value={setting.value as string}>{setting.value as string}</option>
                          </select>
                        ) : (
                          <input
                            type={setting.type}
                            defaultValue={setting.value as string}
                            className="border border-gray-300 rounded-lg px-3 py-1 text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                          />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Save Button */}
      <div className="mt-8">
        <button className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors duration-200 font-medium">
          Save Changes
        </button>
      </div>
    </div>
  );
};

export default Settings;