import { Room, Guest, Booking } from '../types';
import { Payment, Invoice } from '../types';

export const rooms: Room[] = [
  {
    id: '1',
    number: '101',
    type: 'single',
    price: 120,
    capacity: 1,
    amenities: ['WiFi', 'TV', 'Air Conditioning', 'Mini Bar'],
    isAvailable: true,
    image: 'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '2',
    number: '102',
    type: 'double',
    price: 180,
    capacity: 2,
    amenities: ['WiFi', 'TV', 'Air Conditioning', 'Mini Bar', 'Room Service'],
    isAvailable: false,
    image: 'https://images.pexels.com/photos/271624/pexels-photo-271624.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '3',
    number: '201',
    type: 'suite',
    price: 350,
    capacity: 4,
    amenities: ['WiFi', 'TV', 'Air Conditioning', 'Mini Bar', 'Room Service', 'Balcony', 'Kitchenette'],
    isAvailable: true,
    image: 'https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg?auto=compress&cs=tinysrgb&w=400'
  },
  {
    id: '4',
    number: '301',
    type: 'deluxe',
    price: 450,
    capacity: 2,
    amenities: ['WiFi', 'TV', 'Air Conditioning', 'Mini Bar', 'Room Service', 'Ocean View', 'Jacuzzi'],
    isAvailable: true,
    image: 'https://images.pexels.com/photos/1267438/pexels-photo-1267438.jpeg?auto=compress&cs=tinysrgb&w=400'
  }
];

export const guests: Guest[] = [
  {
    id: '1',
    firstName: 'Ahmed',
    lastName: 'Mohamed',
    email: 'ahmed.mohamed@email.com',
    phone: '+252-61-1234567',
    address: 'Hodan District, Mogadishu',
    nationality: 'Somalia',
    idNumber: 'SO123456789'
  },
  {
    id: '2',
    firstName: 'Fatima',
    lastName: 'Hassan',
    email: 'fatima.hassan@email.com',
    phone: '+252-61-2345678',
    address: 'Wadajir District, Mogadishu',
    nationality: 'Somalia',
    idNumber: 'SO987654321'
  }
];

export const bookings: Booking[] = [
  {
    id: '1',
    guestId: '2',
    roomId: '2',
    checkIn: '2025-01-15',
    checkOut: '2025-01-18',
    totalAmount: 540,
    status: 'confirmed',
    specialRequests: 'Late check-in requested',
    createdAt: '2025-01-10T10:00:00Z'
  },
  {
    id: '2',
    guestId: '1',
    roomId: '1',
    checkIn: '2025-01-20',
    checkOut: '2025-01-22',
    totalAmount: 240,
    status: 'pending',
    specialRequests: '',
    createdAt: '2025-01-12T14:30:00Z'
  }
];

export const payments: Payment[] = [
  {
    id: '1',
    bookingId: '1',
    amount: 540,
    method: 'card',
    status: 'completed',
    transactionId: 'TXN-2025-001',
    paidAt: '2025-01-10T15:30:00Z',
    createdAt: '2025-01-10T15:30:00Z',
    notes: 'Payment processed successfully'
  },
  {
    id: '2',
    bookingId: '2',
    amount: 240,
    method: 'cash',
    status: 'pending',
    createdAt: '2025-01-12T14:30:00Z',
    notes: 'Payment due on check-in'
  }
];

export const invoices: Invoice[] = [
  {
    id: '1',
    bookingId: '1',
    guestId: '2',
    roomId: '2',
    subtotal: 540,
    taxes: 54,
    fees: 20,
    total: 614,
    status: 'paid',
    dueDate: '2025-01-15',
    createdAt: '2025-01-10T10:00:00Z',
    paidAt: '2025-01-10T15:30:00Z'
  },
  {
    id: '2',
    bookingId: '2',
    guestId: '1',
    roomId: '1',
    subtotal: 240,
    taxes: 24,
    fees: 10,
    total: 274,
    status: 'sent',
    dueDate: '2025-01-20',
    createdAt: '2025-01-12T14:30:00Z'
  }
];